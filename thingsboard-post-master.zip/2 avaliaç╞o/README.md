# thingsboard-post
Link publico do thingsboard
https://demo.thingsboard.io/dashboards/243dc8a0-bb2e-11ea-b4ad-47e5929eed78
